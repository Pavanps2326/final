package com.cinema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cinema.entity.Admin;
import com.cinema.repository.AdminRepository;


@Service("adminService")
@Scope("singleton")
public class AdminService implements IAdminService{
	
	
	@Autowired
	@Qualifier("adminRepository")
	private AdminRepository adminRepository;

	@Override
	public List<Admin> getAllAdmins() {
		
	 return adminRepository.findAll();
	}

	@Override
	public Admin saveAdmin(Admin adminDetails) {
		
		return adminRepository.save(adminDetails);
	}

	@Override
	public Admin updateAdmin(Admin adminDetails) {
		
		return adminRepository.save(adminDetails);
	}

	@Override
	public void deleteAdmin(int id) {
		
		adminRepository.deleteById(id);
		
	}

	@Override
	public Admin getAdminById(int id) {
		
		return adminRepository.findById(id).get();
	}

}
