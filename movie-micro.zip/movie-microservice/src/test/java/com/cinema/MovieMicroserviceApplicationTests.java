package com.cinema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
