package com.cinema.service;

import java.util.List;

import com.cinema.domain.Payment;



public interface IPaymentService {
	Payment save(Payment payment);
	Payment update(Payment payment);
	void delete(int id);
	List<Payment> getAllPayments();
	Payment getPaymentsById(int id);
	List<Payment> getAllPaymentByDate(String date);
	List<Payment> getAllPaymentByAmount(String amount);
}
