package com.cinema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cinema.domain.Payment;
import com.cinema.repository.PaymentRepository;

@Service("paymentService")
@Scope("singleton")
public class PaymentService implements IPaymentService{

	@Autowired
	@Qualifier("paymentRepository")
	private PaymentRepository paymentRepository;
	
	@Override
	public Payment save(Payment payment) {
		
		return paymentRepository.save(payment);
	}

	@Override
	public Payment update(Payment payment) {
		
		return paymentRepository.save(payment);
	}

	@Override
	public void delete(int id) {
		paymentRepository.deleteById(id);
	}

	@Override
	public List<Payment> getAllPayments() {
		
		return paymentRepository.findAll();
	}

	@Override
	public Payment getPaymentsById(int id) {
		return paymentRepository.findById(id).get();
	}

	@Override
	public List<Payment> getAllPaymentByDate(String date) {
		return paymentRepository.findByDateLike(date);
	}

	@Override
	public List<Payment> getAllPaymentByAmount(String amount) {
		return paymentRepository.findByAmountLike(amount);
	}

}
